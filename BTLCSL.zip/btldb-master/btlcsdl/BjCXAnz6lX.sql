-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 21, 2020 at 02:16 AM
-- Server version: 8.0.13-4
-- PHP Version: 7.2.24-0ubuntu0.18.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `BjCXAnz6lX`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `amount` int(11) NOT NULL,
  `totalMoney` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `dateModified` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_id`, `amount`, `totalMoney`, `user_id`, `dateModified`) VALUES
(29, 3, 4300, 550000000, 47, '2020-04-20'),
(30, 6, 4300, 330000000, 47, '2020-04-20'),
(31, 7, 430, 53000000, 47, '2020-04-20'),
(39, 1, 43, 29990000, 48, '2020-04-20'),
(40, 3, 43, 5500000, 48, '2020-04-20'),
(46, 1, 3, 29990000, 44, '2020-04-20'),
(47, 6, 4, 13200000, 56, '2020-04-20'),
(48, 1, 30, 299900000, 45, '2020-04-20'),
(49, 7, 5, 26500000, 44, '2020-04-20'),
(50, 2, 5, 179950000, 44, '2020-04-20');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `id` int(10) UNSIGNED NOT NULL,
  `orderID` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `amount` int(10) UNSIGNED NOT NULL,
  `totalMoney` int(10) UNSIGNED NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `orderID`, `product_id`, `amount`, `totalMoney`, `status`) VALUES
(1, 1, 7, 4, 15900000, '2020-04-20 10:10:19'),
(2, 1, 7, 4, 15900000, '2020-04-20 10:14:02'),
(3, 1, 2, 2, 71980000, '2020-04-20 10:14:02'),
(4, 17, 2, 2, 71980000, '2020-04-20 10:57:52'),
(5, 18, 1, 1, 29990000, '2020-04-20 14:21:02'),
(6, 19, 3, 1, 11000000, '2020-04-20 15:21:33'),
(7, 20, 1, 1, 29990000, '2020-04-20 15:28:23'),
(8, 21, 1, 23, 59980000, '2020-04-20 15:29:35'),
(9, 21, 2, 23, 71980000, '2020-04-20 15:29:35'),
(10, 21, 3, 2, 11000000, '2020-04-20 15:29:35'),
(11, 1, 1, 23, 29990000, '2020-04-20 15:35:40'),
(12, 1, 2, 1, 35990000, '2020-04-20 15:35:40'),
(13, 23, 2, 1, 35990000, '2020-04-21 01:48:29'),
(14, 24, 1, 2, 59980000, '2020-04-21 01:55:58');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `dateModified` date NOT NULL,
  `phoneNumber` int(10) UNSIGNED NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `dateModified`, `phoneNumber`, `address`) VALUES
(1, 12, '2020-04-20', 1234567, 'trung văn'),
(2, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(3, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(4, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(5, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(6, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(7, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(8, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(9, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(10, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(11, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(12, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(13, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(14, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(15, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(16, 12, '2020-04-20', 123456789, 'Trung Văn- Nam Từ Liêm'),
(17, 40, '2020-04-20', 986155, 'tuyiuiop'),
(18, 41, '2020-04-20', 956346258, 'ưert'),
(19, 56, '2020-04-20', 12344, 'something'),
(20, 48, '2020-04-20', 964875742, '1234'),
(21, 1, '2020-04-20', 12030203, 'adfadf'),
(22, 12, '2020-04-20', 975109203, 'Trung Văn- Nam Từ Liêm'),
(23, 57, '2020-04-21', 975109203, 'Trung Văn- Nam Từ Liêm'),
(24, 64, '2020-04-21', 975109203, 'Trung Văn- Nam Từ Liêm');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `brief description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `dateModified` date NOT NULL,
  `category` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `quantityInStock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `brief description`, `description`, `image`, `amount`, `dateModified`, `category`, `quantityInStock`) VALUES
(1, 'Samsung Galaxy S20 Ultra', 29990000, 'Chính hãng VN/A, bảo hành 12 tháng 1 đổi 1', '-Màn hình:6.9inch Dynamic \r\nAMOLED,120Hz(1080p), HDR10+,\r\nGorilla Glass 6 \r\n-Chipset Exynos 990\r\n-Camera: bộ 4 camera zoom \r\n100x\r\n-RAM:12 GB\r\n-Bộ nhớ:128 GB\r\n-Dung lượng pin:5000 mAh\r\n-Sim: 2 sim vật lý\r\n-Chống nước IP68', 'phone1.jpeg', 0, '0000-00-00', '', 0),
(2, 'Iphone 11 Promax 256GB', 35990000, 'Chính hãng VN/A, bảo hành 12 tháng 1 đổi 1', '-Màn hình: 5.8 inchs Amoled \r\n-Camera trước: 12 MP\r\n-Camera sau: Bộ 3 camera 12MP\r\n-RAM: 6GB\r\n-Bộ nhớ trong: 256 GB\r\n-CPU: Apple A13 Bionic \r\n-Dung lượng pin: 3190 mAh\r\n-Thẻ SIM: Nano-SIM, eSIM\r\n-Chống nước: IP68', 'phone2.jpg', 0, '0000-00-00', '', 0),
(3, 'Oppo A31', 5500000, 'Chính hãng VN/A, bảo hành 12 tháng 1 đổi 1', '-Màn hình: IPS LCD, 6.5\", HD+\r\n-Camera sau: Chính 12 MP,\r\n Phụ 2 MP, 2 MP\r\n-Camera trước: 8 MP\r\n-CPU: MediaTek Helio P35 \r\n-RAM: 4 GB\r\n-Bộ nhớ trong: 128 GB\r\n-Thẻ SIM: 2 Nano SIM 4G\r\nDung lượng pin: 4230 mAh', 'phone3.jpg', 0, '0000-00-00', '', 0),
(4, 'Huawei P30 Pro', 22000000, 'Chính hãng VN/A, bảo hành 12 tháng 1 đổi 1', '-Màn hình: 6.47 inch 2K+\r\n-Camera Trước/Sau: 24 MP\r\n-Camera sau: 40 x 20 x 8 MP\r\nCPU: Kirin 980 (7nm)\r\nBộ Nhớ: 256GB\r\nRAM: 8GB\r\nSIM: 2 nanosim\r\nTính năng: Mở khóa bằng cảm \r\nbiến vân tay', 'phone4.jpg', 0, '0000-00-00', '', 0),
(5, 'Samsung Galaxy Note 10+', 23000000, 'Chính hãng VN/A, bảo hành 12 tháng 1 đổi 1', '-Màn hình rộng: 6.3 inch 2K+ \r\nDynamic AMOLED \r\n-Camera Sau: 12.0 MP + \r\n16.0 MP + 12.0 MP\r\n-Camera Trước: 10.0 MP\r\n-CPU: Exynos 9825 \r\n-Bộ Nhớ: 256GB\r\n-RAM: 8GB\r\n-Bảo mật:Mở khóa bằng khuôn\r\n mặt, Quét mống mắt, vân \r\n tay dưới màn hình', 'phone5.jpeg', 0, '0000-00-00', '', 0),
(6, 'Vsmart Joy 3', 3300000, 'Chính hãng VN/A, bảo hành 12 tháng 1 đổi 1', '-Màn hình: IPS LCD, 6.5\", HD+\r\n-Camera Trước: 8MP\r\n-Camera sau: 13 x 8 x 2 MP\r\n-CPU: Snapdragon 632 8 nhân\r\n-RAM/Bộ nhớ trong: Tùy chọn \r\n 2GB/32GB hoặc 4GB/64GB\r\n-SIM: 2 Nano SIM 4G\r\n-Tính năng: Sạc pin nhanh\r\n\r\n', 'phone6.jpg', 0, '0000-00-00', '', 0),
(7, 'Samsung Galaxy A30s', 5300000, 'Chính hãng VN/A, bảo hành 12 tháng 1 đổi 1', '-Màn hình: 6.5\" HD+, Mặt kính\r\n cong 2.5D, IPS LCD\r\n-Camera trước: 8.0 MP\r\n-Camera sau : Chính 13 MP \r\n Phụ 8 MP, 5 MP\r\n-CPU: Snapdragon 450 \r\n-Tùy chọn RAM / Bộ nhớ trong:\r\n 4GB/64GB và 3GB/32GB\r\n-Dung lượng pin : 4000 mAh\r\n-Thẻ SIM : 2 Sim, Nano SIM\r\n-Tính năng: Mở khóa bằng vân \r\ntay, mở khóa bằng khuôn mặt', 'phone7.jpeg', 0, '0000-00-00', '', 0),
(8, 'OPPO Reno2 F', 6800000, 'Chính hãng VN/A, bảo hành 12 tháng 1 đổi 1', '-Màn hình: AMOLED, 6.5\"\r\n Full HD+\r\n-Camera sau: Chính 48 MP &\r\n Phụ 8 MP, 2 MP, 2 MP\r\n-Camera trước: 16 MP\r\n-CPU: MediaTek Helio P70 \r\n-RAM: 8 GB\r\n-Thẻ SIM: 2 Nano SIM 4G\r\n-Dung lượng pin: 4000 mAh\r\n có sạc nhanh', 'phone8.jpg', 0, '0000-00-00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateModified` date NOT NULL,
  `authorization` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `dateModified`, `authorization`) VALUES
(1, 'nga', 'ttntrinhnga@gmail.com', '123', '2020-04-06', ''),
(8, 'Thảo', 'ttntrinhthao@gmail.com', '12', '2020-04-06', ''),
(9, 'nga', 'ttntrinhoanh@gmail.com', '12345', '2020-04-08', ''),
(10, 'nga', 'ttntrinhN@gmail.com', '12', '2020-04-08', '1'),
(11, 'nga', 'ttntrinhO@gmail.com', '123', '2020-04-08', '1'),
(12, 'oanh', 'ttntrinhOanh0804@gmail.com', '123', '2020-04-08', '1'),
(13, 'nga', 'ttntrinhDAI@gmail.com', '123', '2020-04-08', '1'),
(14, 'nga', 'ttntrinhMN@gmail.com', '123', '2020-04-08', '1'),
(15, '', 'abc@gmail.com', '12345', '2020-04-13', '1'),
(16, '', 'cdf@gmail.com', '12345', '2020-04-13', '1'),
(17, '', 'hab@gmail.com', '123456', '2020-04-14', '1'),
(18, '', 'hbd@gmail.com', '12345', '2020-04-14', '1'),
(19, '', 'abcd@gmail.com', '12345', '2020-04-14', '1'),
(20, '', '123@gmail.com', '12345', '2020-04-14', '1'),
(21, '', 'ttntrinhnga@gmail.com12345', '1234', '2020-04-14', '1'),
(22, '', '123456@gmail.com', '12345', '2020-04-14', '1'),
(23, '', '09@gmail.com', '1234', '2020-04-14', '1'),
(24, '', '12@gmail.com', '123', '2020-04-14', '1'),
(25, '', '000@gmail.com', '0000', '2020-04-14', '1'),
(26, '', '099@gmail.com', '0000', '2020-04-14', '1'),
(27, '', 'ttnTTN@gmail.com', '111', '2020-04-14', '1'),
(28, '', 'ttnTTO@gmail.com', '111', '2020-04-14', '1'),
(29, '', 'TTN@gmail.com', '111', '2020-04-14', '1'),
(30, '', '1111@gmail.com', '1111', '2020-04-14', '1'),
(31, '', 'abcdef@gmail.com', '111', '2020-04-14', '1'),
(32, '', '', '', '2020-04-14', '1'),
(33, '', 'nga@gmail.com', '1234', '2020-04-14', '1'),
(34, '', 'Oanh0804@gmail.com', '12345', '2020-04-14', '1'),
(35, '', '123nga@gmail.com', '12345', '2020-04-14', '1'),
(36, '', 'ga1111@gmail.com', '11111111', '2020-04-14', '1'),
(37, '', 'ttntrinh1111@gmail.com', '11111111', '2020-04-14', '1'),
(38, 'nga', 'oanhtrinhthi@gmail.com', '11111111', '2020-04-17', '1'),
(39, 'nguyvotien', 'nguyvt@gmail.com', '123456', '2020-04-17', '1'),
(40, 'toilaideptrai', '190010khongco@gmail', '<6', '2020-04-20', '1'),
(41, 'Nga ngu người', 'aaaa@gmail.com', '111111', '2020-04-20', '1'),
(42, 'Vũ Thị Trang', 'vuthitrang2772000@gmail.com', '2772000a3', '2020-04-20', '1'),
(43, 'vanhung', 'hungganhh19@gmail.com', 'th06012000', '2020-04-20', '1'),
(44, 'Thảo Hoàng', 'hoangthithao11a3@gmail.com', 'thao11032000', '2020-04-20', '1'),
(45, 'Anhariana', 'sehunanh19112000@gmail.com', '19112000', '2020-04-20', '1'),
(46, 'Trần Nam', 'namtranpt00@gmail.com', '123456', '2020-04-20', '1'),
(47, 'hoangvu', 'hoangvu@gmail.com', '0987816718', '2020-04-20', '1'),
(48, 'besttv1123', 'tranmanhduc0964875742@gmail.com', 'thuyduyen_03', '2020-04-20', '1'),
(49, 'lecuong', 'lecuong@gmail.com', '1111111', '2020-04-20', '1'),
(50, 'ngoclyo', 'ngoclyo@gmail.com', '1111111', '2020-04-20', '1'),
(51, 'sophie', 'sophie@gmail.com', '1111111', '2020-04-20', '1'),
(52, 'lyo', 'lyo@gmail.com', '1111111', '2020-04-20', '1'),
(53, 'aaaa', '180@gmail.com', '11111111', '2020-04-20', '1'),
(54, '18020943', '18020943@gmail.com', '11111111', '2020-04-20', '1'),
(55, 'Nga Ngu Người Dở Hơi Tập Bơi', 'lan@gmail.com', '111111', '2020-04-20', '1'),
(56, 'occhos', 'someone@gmail.com', '12345678', '2020-04-20', '1'),
(57, 'nga', 'ngasophie@gmail.com', '1111111', '2020-04-21', '1'),
(58, 'nga', 'ttnsophie@gmail.com', '1111111', '2020-04-21', '1'),
(59, 'nga', '18020943vnu@gmail.com', '11111111', '2020-04-21', '1'),
(60, 'ngatrinhthi', 'ngatrinhthi@gmail.com', '11111111', '2020-04-21', '1'),
(61, 'ngatrinhthi', 'dddd@gmail.com', '11111111', '2020-04-21', '1'),
(62, 'nga', 'hhhh@gmail.com', '1111111', '2020-04-21', '1'),
(63, '18020943', '18020943nga@gmail.com', '1111111', '2020-04-21', '1'),
(64, '18020943', 'llllll@gmail.com', '1111111', '2020-04-21', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderID` (`orderID`),
  ADD KEY `productID` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userID` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `orderID` FOREIGN KEY (`orderID`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `productID` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `userID` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
    include('../includes/data.php');
    include('../includes/head.php');
    if(!isset($_COOKIE['userId'])){
        header('Location:../user/sign_in.php');
       
    }
    else{
        $user_id = $_COOKIE['userId'];
        if(isset($_GET['buynow'])){
            $id= $_GET['buynow'];
            $result = mysqli_query($connect,"SELECT * FROM products WHERE id = '$id'");
            $row = mysqli_fetch_array($result);
            $link = "../images/".$row['image'];
            $num_of_product = mysqli_query($connect,"SELECT amount FROM cart WHERE product_id = '$id' AND user_id = '$user_id'");// số lượng của sp có $id trong giỏ hàng
            // echo $link;
            $amount_of_product = mysqli_fetch_array($num_of_product);
            $amount = 0;
            // echo $amount_of_product['amount'];
            if($amount_of_product){
                $amount = $amount_of_product['amount'];
            }
        
        }
    }
?>
<div class= "error">
    <?php
        if(isset($_GET['error'])== true){
            echo "
                <div class='alert alert-danger' style='margin-top: 3px'>
                     <strong>Không thành công!</strong> Vui lòng chọn số lượng sản phẩm
                </div>
            ";
            exit();
        }
    ?>
</div>
        <div class="ads">
            <div class="container-fluid row mt-3">
                <div class="col-5 ">
                    <div id="demo" class="carousel slide" data-ride="carousel">

                        <!-- Indicators -->
                        <ul class="carousel-indicators">
                            <li data-target="#demo" data-slide-to="0" class="active"></li>
                            <li data-target="#demo" data-slide-to="1"></li>
                            <li data-target="#demo" data-slide-to="2"></li>
                        </ul>

                        <!-- The slideshow -->
                        <div class="carousel-inner mt-4">
                            <div class="carousel-item active">
                                <img src="<?php echo $link?>" style="width: 100%;" alt="Los Angeles">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo $link?>" style="width: 100%;" alt="Chicago">
                            </div>
                            <div class="carousel-item">
                                <img src="<?php echo $link?>" style="width: 100%;" alt="New York">
                            </div>
                        </div>

                      
                    </div>
                </div>
                <div class="card mb-3 mr-ml-1" style="width: 270px;">
                    
                    <div class="card-body">
                            <h5 class="card-title"><?php echo $row['name']?></h5>
                    <h5 class="price text-danger"><?php echo $row['brief description'] ?></h5>
                    <p class="card-text"><pre><?php echo $row['description']?></pre> </p>
                        <form action="./cart.php" method="GET">
                            <input type="number" name ="amount" value = "<?php echo $amount?>" style="width:50px; margin-right:10px;text-align: center;" >
                            <button type="submit" name="add_cart" value = "<?php echo $id?>" class="btn btn-primary" data-toggle="collapse">Thêm vào giỏ hàng</button>
                        </form>
                     </div>
                        <!-- <div class="collapse multi-collapse " id="desphone' . $i . '">
                            <div class="card card-body bg-primary text-light">' . $row[$i][4] . ' </div> -->
                            
               </div>
            </div>';
                
            </div>

           
        </div>
<?php 
    include('../includes/foot.php');
?>    
    

<div class="body">
    <div class="container-fluid row mt-3">
        <div class="col-8 ">
            <div id="demo" class="carousel slide" data-ride="carousel">

                <!-- Indicators -->
                <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                    <li data-target="#demo" data-slide-to="1"></li>
                    <li data-target="#demo" data-slide-to="2"></li>
                </ul>

                <!-- The slideshow -->
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="../images/ad_1.png" style="width: 100%;" alt="Los Angeles">
                    </div>
                    <div class="carousel-item">
                        <img src="../images/ad_2.jpg" style="width: 100%;" alt="Chicago">
                    </div>
                    <div class="carousel-item">
                        <img src="../images/ad_3.jpg" style="width: 100%;" alt="New York">
                    </div>
                </div>

                <!-- Left and right controls -->
                <a class="carousel-control-prev" href="#demo" data-slide="prev"><span class="carousel-control-prev-icon"></span></a>
                <a class="carousel-control-next" href="#demo" data-slide="next"><span class="carousel-control-next-icon"></span></a>

            </div>
        </div>
        <div class="col-3">
            <div class="media mt-2">
                <img class="mr-3" src="../images/ad1.jpg">

            </div>
            <div class="media mt-4">
                <img class="mr-3" src="../images/ad2.jpg">

            </div>
            <div class="media mt-4">
                <img class="mr-3" src="../images/ads2.jpg">

            </div>

        </div>
    </div>
    <div class="container-fluid  mt-3" style="margin-left:150px">

        <img src="./images/ads3.jpg">

    </div>

    <!-- các dòng diện thoại -->
    
    <div class="container-fluid  mt-3" style="margin-left:150px">
        <img src="./images/ads3.jpg">
    </div>
    <div class="container mt-5" id="content">
        <div class="content-card d-flex justify-content-between flex-wrap">
            <div class="card mb-3 mr-ml-1" style="width: 18vw;">
                <img src="../images/phone1.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Galaxy S20 Utral</h5>
                    <p class="card-text">Siêu phẩm đt của Samsung</p>
                    <a href="#" class="btn btn-primary">Buy now</a>
                </div>
            </div>
            <div class="card mb-3" style="width: 18vw;">
                <img src="../images/phone1.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Galaxy S20 Utral</h5>
                    <p class="card-text">Siêu phẩm đt của Samsung</p>
                    <a href="#" class="btn btn-primary">Buy now</a>
                </div>
            </div>
            <div class="card mb-3" style="width: 18vw;">
                <img src="../images/phone1.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Galaxy S20 Utral</h5>
                    <p class="card-text">Siêu phẩm đt của Samsung</p>
                    <a href="#" class="btn btn-primary">Buy now</a>
                </div>
            </div>
            <div class="card mb-3" style="width: 18vw;">
                <img src="../images/phone1.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Galaxy S20 Utral</h5>
                    <p class="card-text">Siêu phẩm đt của Samsung</p>
                    <a href="#" class="btn btn-primary">Buy now</a>
                </div>
            </div>
            <div class="card mb-3" style="width: 18vw;">
                <img src="../images/phone1.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Galaxy S20 Utral</h5>
                    <p class="card-text">Siêu phẩm đt của Samsung</p>
                    <a href="#" class="btn btn-primary">Buy now</a>
                </div>
            </div>
            <div class="card mb-3" style="width: 18vw;">
                <img src="../images/phone1.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Galaxy S20 Utral</h5>
                    <p class="card-text">Siêu phẩm đt của Samsung</p>
                    <a href="#" class="btn btn-primary">Buy now</a>
                </div>
            </div>
            <div class="card mb-3" style="width: 18vw;">
                <img src="../images/phone1.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Galaxy S20 Utral</h5>
                    <p class="card-text">Siêu phẩm đt của Samsung</p>
                    <a href="#" class="btn btn-primary">Buy now</a>
                </div>
            </div>
            <div class="card mb-3" style="width: 18vw;">
                <img src="../images/phone1.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Galaxy S20 Utral</h5>
                    <p class="card-text">Siêu phẩm đt của Samsung</p>
                    <a href="#" class="btn btn-primary">Buy now</a>
                </div>
            </div>
        </div>


    </div>
</div>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <script src="../jquery/jquery.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <link href="../CSS/style.css" rel="stylesheet" />


</head>

<body>
    <!-- Thanh nav -->
    <div class=" header">

        <!--/.Navbar-->


        <nav class="navbar navbar-expand-sm navbar-dark bg-info">
            <!-- <a href="../index.php"> <img class="ml-5% mr-3% " src="../images\logoWeb.png"></a> -->
            <!-- <i class="fas fa-home ml-2 mr-2"></i> -->
            <a class="navbar-brand t" href="../index.php">
                <strong>Trang chủ</strong> </a>

        </nav>
    </div>
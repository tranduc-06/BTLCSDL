<?php 
    $connect = mysqli_connect('remotemysql.com:3306','BjCXAnz6lX','4mWNB9p42q','BjCXAnz6lX');
?>
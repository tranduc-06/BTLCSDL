<div class="footer">
        <!-- Footer -->
        <footer class="page-footer font-small blue pt-4" style="background-color:  rgb(238, 238, 238) ">

            <!-- Footer Links -->
            <div class="container-fluid text-center text-md-left" style="background-color: white ">

                <!-- Grid row -->
                <div class="row">
                    <div class="col-md-1 mt-md-0 mt-3">




                    </div>
                    <!-- Grid column -->
                    <div class="col-md-3 mt-md-4 mt-3">

                        <!-- Content -->
                        <h5 class="text-uppercase">
                            <t>Giới thiệu về team
                        </h5>
                        <strong>Trần Nguyễn Phương Nam<br>Trịnh Thị Nga<br>Trần Mạnh Đức</strong>

                    </div>
                    <!-- Grid column -->

                    <hr class="clearfix w-100 d-md-none pb-3">

                    <!-- Grid column -->
                    <div class="col-md-5 mt-md-4 mb-3">

                        <!-- Links -->
                        <h5 class="text-uppercase">Thông tin liên hệ</h5>

                        <ul class="list-unstyled">
                            <li>
                                <p>
                                    -Hotline: 0388544341 | 098899999
                                </p>
                            </li>
                            <li>
                                <p>
                                    -Địa chỉ: G2 Đại học Công Nghệ- Vnu
                                </p>
                            </li>
                            <li>
                                <p>
                                    - Giờ làm việc: (08h00 - 22h00 | Tất cả các ngày trong tuần)
                                </p>
                            </li>

                        </ul>

                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-3 mt-md-4 mb-3">
                          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1968.1451296547582!2d105.78161544125925!3d21.037843911934818!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab354920c233%3A0x5d0313a3bfdc4f37!2sVNU%20University%20of%20Engineering%20and%20Technology!5e0!3m2!1sen!2sbd!4v1587431489909!5m2!1sen!2sbd" width="300" height="200" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

                    </div>
                    <!-- Grid column -->

                </div>
                <!-- Grid row -->

            </div>
            <!-- Footer Links -->

            <!-- Copyright -->
            <div class="footer-copyright text-center py-3">
                <a href="https://mdbootstrap.com/"></a>
            </div>
        </footer>
    </div>

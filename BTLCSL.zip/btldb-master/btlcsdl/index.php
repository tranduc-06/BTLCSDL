<!-- update ngày 14/04 -->
    <!-- // echo "<h1>Nội dung chính trong này</h1>";
// vscode terminal php -S localhost:8000 -->
<!-- sửa giỏ hàng 20/04 -->
<?php
    include('./includes/head_index.php');
?>
    <div class="body">
        <!-- quảng cáo -->

        <div class="ads">
            <div class="container-fluid row mt-3">
                <div class="col-12  ml-3">
                    <div id="demo" class="carousel slide" data-ride="carousel">

                        <!-- Indicators -->
                        <ul class="carousel-indicators">
                            <li data-target="#demo" data-slide-to="0" class="active"></li>
                            <li data-target="#demo" data-slide-to="1"></li>
                            <li data-target="#demo" data-slide-to="2"></li>
                        </ul>

                        <!-- The slideshow -->
                        <div class="carousel-inner mt-4">
                            <div class="carousel-item active">
                                <img src="./images/ad_1.png" style="width: 100%;" alt="Los Angeles">
                            </div>
                            <div class="carousel-item">
                                <img src="./images/ad_2.jpg" style="width: 100%;" alt="Chicago">
                            </div>
                            <div class="carousel-item">
                                <img src="./images/ad_3.jpg" style="width: 100%;" alt="New York">
                            </div>
                        </div>

                        <!-- Left and right controls -->
                        <a class="carousel-control-prev" href="#demo" data-slide="prev"><span class="carousel-control-prev-icon"></span></a>
                        <a class="carousel-control-next" href="#demo" data-slide="next"><span class="carousel-control-next-icon"></span></a>

                    </div>
                </div>
                <!-- <div class="col-4 ">
                    <div class="media mt-4">
                        <img class="ml-4" src="./images/ad1.jpg ">

                    </div>
                    <div class="media mt-3">
                        <img class="ml-4" src="./images/ad2.jpg">

                    </div>
                    <div class="media mt-3">
                        <img class="ml-4" src="./images/ads2.jpg">

                    </div>
                </div> -->
            </div>
            <!-- <div class="container-fluid row mt-3">
                <img src="./images/ads3.jpg">
            </div> -->
        </div>

        <!-- các mẫu điện thoại -->
        <?php
        include('phone/phone.php');
        ?>

</body>
<?php include('./includes/foot.php');?>

</html>